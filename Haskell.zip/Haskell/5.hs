pagaImp::Int -> Float -> Bool
pagaImp edad ingresos =edad>=18&&ingresos>=53206000
