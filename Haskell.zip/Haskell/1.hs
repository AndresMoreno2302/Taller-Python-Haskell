verifEdad::Int -> String
verifEdad edad =
    if edad>=18
        then "Eres mayor de edad."
        else "Eres menor de edad."
