try:
    num1=float(input("Ingrese el numerador: "))
    num2=float(input("Ingrese el denominador: "))
    resu=num1/num2
    print("El resultado es:", resu)
except ZeroDivisionError:
    print("Error: No se puede dividir entre cero.")
