
contrasena="PythonHaskell"

ent=input("Ingrese su contraseña: ")

if contrasena.lower()==ent.lower():
    print("Contraseña correcta.")
else:   
    print("Contraseña incorrecta.")
