edad=int(input("Digite su edad: "))

if edad<12:
    precio=10000
elif edad<=18:
    precio=17000
else:
    precio=20000

print(f"El precio de la entrada es: ${precio}")
