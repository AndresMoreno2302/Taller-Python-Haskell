Punt=float(input("Ingrese la puntuación del empleado (0-10): "))

if Punt>=9:
    nivel="Excelente"
    Paga=3000000
elif Punt>=7:
    nivel="Bueno"
    Paga=1500000
else:
    nivel="Insuficiente"
    Paga=700000

print(f"Nivel de rendimiento: {nivel}, Tu pago es de: ${Paga}")
