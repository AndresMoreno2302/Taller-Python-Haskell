nombre=input("Ingrese su nombre: ")
gen=input("Ingrese su género (M/F): ")

if gen.upper()=="F":
    grupo="Grupo F"
else:
    grupo="Grupo M"

print(f"{nombre}, perteneces al {grupo}.")
