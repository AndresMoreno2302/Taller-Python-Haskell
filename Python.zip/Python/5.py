edad = int(input("Ingrese su edad: "))
ingresos = float(input("Ingrese sus ingresos mensuales: "))

if edad >= 18 and ingresos >= 53206000:
    print("Debe pagar impuestos.")
else:
    print("No debe pagar impuestos.")
