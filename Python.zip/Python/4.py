num=int(input("Ingrese un numero entero: "))

if num%2==0:
    print("El numero es par.")
else:
    print("El numero es impar.")