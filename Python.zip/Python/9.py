
Pizza="Queso, tomate"

ingVeg= ["Pimenton", "Champinon"]
ingNoveg= ["Pepperoni", "Jamón"]

resp=input("¿Quieres pizza vegetariana? (si/no): ").strip().lower()
Veg=resp in("si", "Si")

if Veg:
    tipo="Vegetariana"
    menu=ingVeg
else:
    tipo="No vegetariana"
    menu=ingNoveg

print("\nElige un ingrediente adicional:")
for x, ing in enumerate(menu, start=1):
    print(f"{x}. {ing}")

try:
    Elec=int(input("Opcion (numero): "))
    if 1<=Elec<=len(menu):
        ingrediente=menu[Elec-1]
        print(f"\nHas pedido una pizza {tipo} con {Pizza} y {ingrediente}.")
    else:
        print("Opcion invalida.")
except ValueError:
    print("Debes ingresar un numero valido.")
